<div align="center">

# 🛍️ Mall Customer Segmentation
### Discover customer groups with Unsupervised Machine Learning

**K-Means • Hierarchical Clustering • DBSCAN • PCA • t-SNE**

*Turning customer data into practical retail insights.*

</div>

---

## 🌟 Project Overview

This project explores mall customer data and applies **unsupervised learning** to identify customers with similar characteristics. It uses three selected numerical features — **Age, Annual Income, and Spending Score** — and compares different clustering approaches.

The goal is to help a retail business understand customer groups and think about more relevant marketing, loyalty, and customer-engagement strategies.

## 🎯 Project Objectives

- Inspect and prepare the dataset for analysis.
- Scale numerical features before distance-based clustering.
- Build and compare **K-Means**, **Hierarchical Clustering**, and **DBSCAN**.
- Use the **Elbow Method** and **Silhouette Score** to assess K-Means choices.
- Explore the data with **PCA** and **t-SNE** visualizations.
- Interpret customer segments and propose business recommendations.

## 🧰 Tools & Technologies

| Tool | Purpose |
|---|---|
| Python | Analysis and modeling |
| Pandas, NumPy | Data handling and numerical operations |
| Matplotlib, Seaborn, Plotly | Charts and visual exploration |
| scikit-learn | Scaling, clustering, PCA, t-SNE, evaluation |
| SciPy | Hierarchical clustering and dendrogram |
| Google Colab / Jupyter Notebook | Interactive workflow |

## 📁 Project Files

- `Mall_Customer_Spending_Analysis_and_Customer_Segmentation.ipynb` — notebook containing code, outputs, and analysis.
- `requirements.txt` — Python packages needed to run the notebook.
- `visualizations.pdf` — compiled PDF of the charts available in the notebook.
- `visualizations/` — individual chart images extracted from notebook outputs.
- `README.md` — project overview and setup instructions.

## 🚀 Getting Started

### Option 1 — Google Colab
1. Upload the `.ipynb` notebook to Google Drive.
2. Open it with Google Colab.
3. Upload the mall customer Excel dataset when prompted, or update the dataset path in the loading cell.
4. Run the notebook cells from top to bottom.

### Option 2 — Run locally
1. Install Python 3.10 or later.
2. Download or clone this project folder.
3. Create and activate a virtual environment (recommended).
4. Install dependencies:

```bash
pip install -r requirements.txt
```

5. Place the Excel dataset where the notebook expects it, or update the file path in the data-loading cell.
6. Start Jupyter:

```bash
jupyter notebook
```

## 🧪 Methods Included

### 1. K-Means
Partitions customers into a chosen number of groups. The notebook includes cluster visualization, the Elbow Method, and Silhouette Score analysis.

### 2. Hierarchical Clustering
Builds a hierarchy of customer similarities. A dendrogram and a cluster visualization are used to inspect the grouping.

### 3. DBSCAN
Groups dense regions and can identify noise points. Its output depends on settings such as `eps` and `min_samples`, so results should be interpreted alongside the selected feature scaling.

### 4. PCA
Projects data into principal components to summarize variance and support visualization. PCA is a linear dimensionality-reduction method.

### 5. t-SNE
Creates a two-dimensional representation that can help reveal local patterns. Distances and gaps in a t-SNE plot should be interpreted cautiously; it is mainly an exploratory visualization, not proof that clusters are real.

## 💡 Business Interpretation

Customer clusters can support ideas such as:
- **High-spending customers:** consider loyalty benefits, personalized recommendations, and retention campaigns.
- **High-income but lower-spending customers:** investigate barriers to purchase and test targeted offers.
- **Lower-income or budget-conscious customers:** promote value bundles, seasonal discounts, and affordable product ranges.
- **Younger or older customer groups:** compare preferences before choosing suitable campaigns.

These are **possible strategies**, not confirmed findings for every cluster. Use the actual cluster profiles and averages produced by the notebook before assigning a label to any cluster.

## 📊 Evaluation Notes

- Compare cluster sizes and feature averages, not just chart appearance.
- Silhouette scores are useful for some clustering comparisons, but they may not be meaningful for DBSCAN when it produces one cluster or labels most observations as noise.
- Keep the same scaled input features when comparing models fairly.
- Cluster labels are arbitrary identifiers; label `0` is not inherently better than label `1`.

## ⚠️ Limitations

- Results depend on the chosen features, scaling, algorithm settings, and dataset quality.
- Clustering shows similarity patterns; it does not establish cause and effect.
- Validate recommendations with business context and additional customer data before taking action.
- Make sure the dataset's source and usage permissions are appropriate for your submission.

## 📌 Deliverables Checklist

- [x] Notebook with code and existing outputs
- [x] K-Means, Hierarchical Clustering, and DBSCAN workflow
- [x] PCA and t-SNE analysis
- [x] Cluster interpretation and business recommendations section
- [x] `requirements.txt`
- [x] Visualization PDF and individual plot images
- [ ] Upload the notebook and project files to Google Drive or GitHub and add your submission URL here

**Submission link:** _Add your Google Drive or GitHub repository URL after uploading._

---

<div align="center">

**Made for learning, analysis, and data-driven retail decision-making.**  
*Keep exploring. Keep learning. Let data tell the story.*

</div>
